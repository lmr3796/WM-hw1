#ifndef MERGE_H
#define MERGE_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

void merge (vector <string> &files, string outfile);

#endif
