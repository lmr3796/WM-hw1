#! /usr/bin/env bash
cd tools && make
